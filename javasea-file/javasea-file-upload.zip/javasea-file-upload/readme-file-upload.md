# 文件上传整合
## 使用到的框架
thymeleaf：用于显示文件上传的页面，方便测试。当然，也可以用pastman等工具测试。


## 整合步骤
### 添加依赖
### 编写controller
## 测试
上传页面URL：http://localhost:8080/upload



